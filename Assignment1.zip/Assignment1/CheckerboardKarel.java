/*
 * File: CheckerboardKarel.java
 * ----------------------------
 * When you finish writing it, the CheckerboardKarel class should draw
 * a checkerboard using beepers, as described in Assignment 1.  You
 * should make sure that your program works for all of the sample
 * worlds supplied in the starter folder.
 */

import stanford.karel.*;

public class CheckerboardKarel extends SuperKarel {

	// Karel uses beepers to creat a checkerboard pattern
	
	
	
	public void run() {
	
		try2rows();
		
		while (frontIsClear()) {
			move();
			turnRight();
			try2rows();
		}
			
		
	}
	
	public void try2rows() {
		
		putBeeper();
		if (frontIsClear()) {
			move();
		}
		
		while (frontIsClear()) {
			move();
			putBeeper();
			while (frontIsClear()) {
				move();
				break;
			}
		}
		turnLeft();
		if (frontIsClear()) {
			move();
		}else {
			turnRight();
			return;
		}
			
		turnLeft();
		while (frontIsClear()) {
			move();
		}
		turnAround();
		
		while (frontIsClear()) {
			move();
			putBeeper();
			while (frontIsClear()) {
				move();
				break;
			}
		}
		turnAround();
		
		while (frontIsClear()) {
				move();
		}
		turnRight();
		
		
	}
	
}
