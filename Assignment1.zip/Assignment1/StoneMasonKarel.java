/*
 * File: StoneMasonKarel.java
 * --------------------------
 * The StoneMasonKarel subclass as it appears here does nothing.
 * When you finish writing it, it should solve the "repair the quad"
 * problem from Assignment 1.  In addition to editing the program,
 * you should be sure to edit this comment so that it no longer
 * indicates that the program does nothing.
 */

import stanford.karel.*;

public class StoneMasonKarel extends SuperKarel {

	public void run() {
		fix();
		for (int m = 0; m < 3; m++) {
			Move();
			fix();
		}
		
	}
	
	
	private void fix() {
	// this makes Karel fix the current column
	// and come back to the bottom, facing East
		turnLeft();
		if (noBeepersPresent()) {
			putBeeper();
		}
		for (int i = 0; i < 4; i++) {
			move();
			if (noBeepersPresent()) {
				putBeeper();
			}
		}
		turnAround();
		Move();
		turnLeft();
	}
	
	
	

	
	private void Move() {
		// this makes Karel to move 4 times
		move();
		move();
		move();
		move();
		
	}

}
