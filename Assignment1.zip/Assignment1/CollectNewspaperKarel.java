/*
 * File: CollectNewspaperKarel.java
 * --------------------------------
 * At present, the CollectNewspaperKarel subclass does nothing.
 * Your job in the assignment is to add the necessary code to
 * instruct Karel to walk to the door of its house, pick up the
 * newspaper (represented by a beeper, of course), and then return
 * to its initial position in the upper left corner of the house.
 */

// make Karel move to the door and 
// collect the beeper




import stanford.karel.*;

public class CollectNewspaperKarel extends Karel {
	public void run() {
		
		move();
		move();
		turnRight();
		move();
		turnLeft();
		move();
		pickBeeper();
		turnAround();
		Move();
		turnRight();
		move();
		turnRight();
		
		
		
		
	}

	private void turnRight() {
	// this makes Karel to turn Right
	turnLeft();
	turnLeft();
	turnLeft();
	}

	private void turnAround() {
	// this makes Karel to turn around
	turnLeft();
	turnLeft();
	}

	private void Move() {
	// this makes Karel to move forward three times
	move();
	move();
	move();
	}
	
}
