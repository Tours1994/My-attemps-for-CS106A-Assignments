/*
 * File: MidpointFindingKarel.java
 * -------------------------------
 * When you finish writing it, the MidpointFindingKarel class should
 * leave a beeper on the corner closest to the center of 1st Street
 * (or either of the two central corners if 1st Street has an even
 * number of corners).  Karel can put down additional beepers as it
 * looks for the midpoint, but must pick them up again before it
 * stops.  The world may be of any size, but you are allowed to
 * assume that it is at least as tall as it is wide.
 */

import stanford.karel.*;

public class MidpointFindingKarel extends SuperKarel {

	// this program lets Karel locate the position of the 
	// middle point of 1st Street, and leave a Beeper there
	
	public void run() {
		
		// this while loop uses a float counter i
		// to check the length of the world
		float i = 1;
		while (frontIsClear()) {
			move();
			i++;
		}
		// ready to go back (to stop at half way)
		turnAround();
		
		// this for loop make use of the counter and locate the middle point
		for (int m = 0; m < (0.5*i - 1); m++) {
			move();
		}
		putBeeper();
		turnAround();
	}

}
